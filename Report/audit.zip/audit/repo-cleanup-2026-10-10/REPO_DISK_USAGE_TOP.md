# REPO_DISK_USAGE_TOP

Measured logical bytes (not allocated size, not compressed). Total 6.87 GB.

## 20 heaviest folders (leaf-aware; parent/child overlaps noted)

| # | Path | MB | Files | Git | Class |
|---:|---|---:|---:|---|---|
| 1 | `research` | 2139.0 | 59,627 | T4/U0/I59623 | MIXED (venvs REGENERABLE/LOW + source) |
| 2 | `research/.venv` | 1358.3 | 22,046 | T0/U0/I22046 | REGENERABLE_CANDIDATE |
| 3 | `remotion` | 1237.3 | 15,103 | T311/U49/I14743 | MIXED (source KEEP_CRITICAL + node_modules + staging) |
| 4 | `.claude` | 1151.7 | 2,029 | T1/U0/I2028 | UNKNOWN_HOLD (worktree) + skills |
| 5 | `.claude/worktrees` | 1151.7 | 2,028 | T0/U0/I2028 | UNKNOWN_HOLD |
| 6 | `out` | 1043.0 | 68 | T0/U0/I68 | MIXED (APPROVED finals + REGENERABLE caches) |
| 7 | `node_modules` | 1013.3 | 1,871 | T0/U0/I1871 | REGENERABLE (npm ci) - KEEP |
| 8 | `remotion/node_modules` | 970.8 | 14,719 | T0/U0/I14719 | KEEP_CRITICAL |
| 9 | `research/.venv-deep` | 780.6 | 37,576 | T0/U0/I37576 | REGENERABLE_CANDIDATE |
| 10 | `out/longform-5c` | 466.6 | 2 | T0/U0/I2 | REGENERABLE_CANDIDATE |
| 11 | `out/incremental-5b` | 305.4 | 28 | T0/U0/I28 | REGENERABLE_CANDIDATE |
| 12 | `projects` | 221.2 | 674 | T644/U30/I0 | REVIEW_BY_PROJECT (KEEP_APPROVED/KEEP_TEST/KEEP_EVIDENCE) |
| 13 | `remotion/.render-binaries` | 220.1 | 22 | T0/U0/I22 | KEEP_CRITICAL |
| 14 | `out/incremental-5c` | 177.8 | 13 | T0/U0/I13 | REGENERABLE_CANDIDATE |
| 15 | `.git` | 132.1 | 417 | T0/U0/I417 | KEEP_CRITICAL |
| 16 | `projects/pilot-sky-blue-canonical` | 105.0 | 136 | T106/U30/I0 | KEEP_APPROVED |
| 17 | `projects/pilot-sky-blue-canonical/render` | 86.0 | 40 | T10/U30/I0 | KEEP_APPROVED |
| 18 | `out/final` | 56.8 | 14 | T0/U0/I14 | KEEP_APPROVED |
| 19 | `.opencode` | 55.4 | 3,865 | T0/U0/I3865 | MIXED (node_modules + config + gitlink) |
| 20 | `.opencode/node_modules` | 52.5 | 3,667 | T0/U0/I3667 | KEEP_CRITICAL |

(Overlap: parents such as `research`, `out`, `remotion` contain listed children.)

## 30 heaviest files (excluding bulk folders)

| # | MB | Git | Path | Class | Dup group |
|---:|---:|---|---|---|---|
| 1 | 298.7 | IGNORED | `out/longform-5c/longform-20min.mp4` | REGENERABLE_CANDIDATE |  |
| 2 | 168.0 | IGNORED | `out/longform-5c/longform-10min.mp4` | REGENERABLE_CANDIDATE |  |
| 3 | 49.8 | IGNORED | `out/incremental-5b/ref-v2-c.mp4` | REGENERABLE_CANDIDATE |  |
| 4 | 48.5 | IGNORED | `out/final/pilot-4b.mp4` | KEEP_APPROVED |  |
| 5 | 46.9 | IGNORED | `out/incremental-5c/ref-5c-c.mp4` | REGENERABLE_CANDIDATE |  |
| 6 | 45.0 | IGNORED | `out/incremental-5b/ref-v2.mp4` | REGENERABLE_CANDIDATE |  |
| 7 | 42.6 | IGNORED | `out/incremental-5b/ref-v1.mp4` | REGENERABLE_CANDIDATE |  |
| 8 | 39.5 | IGNORED | `out/incremental-5b/inc-v2-c.mp4` | REGENERABLE_CANDIDATE |  |
| 9 | 37.5 | IGNORED | `out/incremental-5c/inc-5c-c.mp4` | REGENERABLE_CANDIDATE |  |
| 10 | 32.3 | IGNORED | `out/incremental-5b/inc-v2.mp4` | REGENERABLE_CANDIDATE |  |
| 11 | 32.2 | TRACKED | `projects/phase1hyg-validation/inventory/repo-inventory.json` | ARCHIVE_CANDIDATE |  |
| 12 | 32.1 | TRACKED | `projects/validation/post-1h-physical-migration/rollback/repo-inventory.before.json` | ARCHIVE_CANDIDATE |  |
| 13 | 31.1 | IGNORED | `out/incremental-5b/inc-v1.mp4` | REGENERABLE_CANDIDATE |  |
| 14 | 31.1 | IGNORED | `out/incremental-5c/inc-5c.mp4` | REGENERABLE_CANDIDATE |  |
| 15 | 29.4 | IGNORED | `out/incremental-5b/cache/CAS/sha256/3915dcc4e6bbd82d99e626c3ce227944ebd7a2fe01aa5d7294a8fad0eca8daf9` | REGENERABLE_CANDIDATE | DUP-02-3915dcc4e6bb |
| 16 | 29.4 | IGNORED | `out/incremental-5b/chunk-v1-0-900.mp4` | REGENERABLE_CANDIDATE | DUP-02-3915dcc4e6bb |
| 17 | 29.4 | IGNORED | `out/incremental-5c/base-chunk-0-900.mp4` | REGENERABLE_CANDIDATE | DUP-03-153c9dea4cb3 |
| 18 | 29.4 | IGNORED | `out/incremental-5c/cand-chunk-0-900.mp4` | REGENERABLE_CANDIDATE | DUP-03-153c9dea4cb3 |
| 19 | 18.1 | IGNORED | `out/pilot-sky-blue-canonical/final.mp4` | KEEP_APPROVED | DUP-01-7954a86a793c |
| 20 | 18.1 | IGNORED | `out/pilot-sky-blue-canonical/final.prev.mp4` | DUPLICATE_CANDIDATE | DUP-01-7954a86a793c |
| 21 | 18.1 | TRACKED | `projects/pilot-sky-blue-canonical/render/attempts/attempt-006/output.mp4` | KEEP_APPROVED | DUP-01-7954a86a793c |
| 22 | 17.2 | UNTRACKED | `projects/pilot-sky-blue-canonical/render/attempts/attempt-001/output.mp4` | KEEP_APPROVED |  |
| 23 | 15.1 | UNTRACKED | `projects/pilot-sky-blue-canonical/render/attempts/attempt-005/output.mp4` | KEEP_APPROVED |  |
| 24 | 15.0 | UNTRACKED | `projects/pilot-sky-blue-canonical/render/attempts/attempt-003/output.mp4` | KEEP_APPROVED |  |
| 25 | 14.7 | UNTRACKED | `projects/pilot-sky-blue-canonical/render/attempts/attempt-004/output.mp4` | KEEP_APPROVED |  |
| 26 | 8.2 | UNTRACKED | `Report/evidence/phase-6a/canonical-pilot/preview-en-x1.2.mp4` | UNKNOWN_HOLD |  |
| 27 | 7.6 | UNTRACKED | `Report/evidence/phase-6a/canonical-pilot/preview-en-x1.3.mp4` | UNKNOWN_HOLD |  |
| 28 | 6.9 | UNTRACKED | `Report/evidence/phase-6a/canonical-pilot/preview-en-x1.5.mp4` | UNKNOWN_HOLD |  |
| 29 | 3.2 | TRACKED | `projects/pilot-sky-blue/assets/voice/narration-track/fnt-cfd231152fcd.wav` | KEEP_TEST | DUP-05-6be6d491d754 |
| 30 | 3.2 | TRACKED | `projects/pilot-sky-blue-canonical/assets/voice/narration-track/fnt-cfd231152fcd.wav` | KEEP_APPROVED | DUP-05-6be6d491d754 |

## Recoverable bytes by confidence (MEASURED size of the candidate path; true reclaim = same, nothing compressed)

| Category | Action | Confidence | Files | MB | Notes |
|---|---|---|---:|---:|---|
| Regenerable test output caches | REVIEW_DELETE / REVIEW_ARCHIVE | MEDIUM | 43 | 949.9 | regen = re-run of owning test; NOT executed in audit |
| Untracked staging duplicates | REVIEW_DELETE | MEDIUM | 14 | 10.0 | identical copies exist under pilot-sky-blue-canonical staging |
| Scratch leftovers (kokoro-test.wav, remotion/out, playwright-report, __pycache__) | REVIEW_DELETE | MEDIUM | 5 | 0.8 | tiny |
| Historical hygiene inventories (tracked) | REVIEW_ARCHIVE | LOW | 2 | 64.4 | tracked; git history keeps a copy, working tree only |
| Python venvs (research) | KEEP (REVIEW only if research stops) | LOW | 59,622 | 2138.9 | reinstall untested |
| npm node_modules (3 trees) | KEEP | HIGH regenerable / conditions | 20,257 | 2036.6 | npm ci; do not delete during active cycle |
| Stale claude worktree | UNKNOWN_HOLD | - | 2,028 | 1151.7 | holds 16 MB non-reproduced ignored files; see candidates |

**Sum of MEDIUM-confidence candidates: 960.6 MB.** HIGH-confidence deletable bytes: ~0 MB (nothing large is provably safe without executing regeneration). Duplicate-content groups confirmed by SHA-256 (files ≥ 64 KiB, outside bulk folders): 65 groups, 144.3 MB of redundant copies — most are intentional (approved finals, tracked+staged copies) and are NOT all candidates.

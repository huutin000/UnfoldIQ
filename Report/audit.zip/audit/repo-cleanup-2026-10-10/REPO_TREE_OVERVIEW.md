# REPO_TREE_OVERVIEW

Generated 2026-10-10 by read-only scan of `D:/Project/UNFOLDIQ` (HEAD 1096429, branch main). Logical bytes (not allocated size). Symlinks/junctions found: **0**. Bulk folders (node_modules, .venv*, .git, .render-binaries, .claude/worktrees) are summarised, not enumerated.

**TOTAL: 6.87 GB, 84,830 files — TRACKED 2079 (173.4 MB) / UNTRACKED 88 (132.0 MB) / IGNORED 82,663 (6726.6 MB, 95.7% of disk)**

Git-tracked source is only 2.5% of the disk footprint; ~96% is ignored/reinstallable/generated.

## A. Depth-1 view

| Path | Class (primary) | Files | MB | T / U / I files |
|---|---|---:|---:|---|
| `research/` | MIXED (venvs REGENERABLE/LOW + source) | 59,627 | 2139.0 | 4 / 0 / 59,623 |
| `remotion/` | MIXED (source KEEP_CRITICAL + node_modules + staging) | 15,103 | 1237.3 | 311 / 49 / 14,743 |
| `.claude/` | UNKNOWN_HOLD (worktree) + skills | 2,029 | 1151.7 | 1 / 0 / 2,028 |
| `out/` | MIXED (APPROVED finals + REGENERABLE caches) | 68 | 1043.0 | 0 / 0 / 68 |
| `node_modules/` | REGENERABLE (npm ci) - KEEP | 1,871 | 1013.3 | 0 / 0 / 1,871 |
| `projects/` | REVIEW_BY_PROJECT (KEEP_APPROVED/KEEP_TEST/KEEP_EVIDENCE) | 674 | 221.2 | 644 / 30 / 0 |
| `.git/` | KEEP_CRITICAL | 417 | 132.1 | 0 / 0 / 417 |
| `.opencode/` | MIXED (node_modules + config + gitlink) | 3,865 | 55.4 | 0 / 0 / 3,865 |
| `Report/` | KEEP_EVIDENCE | 301 | 30.5 | 292 / 8 / 1 |
| `tests/` | KEEP_TEST | 213 | 2.4 | 213 / 0 / 0 |
| `lib/` | KEEP_CRITICAL | 212 | 2.1 | 212 / 0 / 0 |
| `flow-companion/` | KEEP_CRITICAL | 86 | 1.2 | 53 / 0 / 33 |
| `scripts/` | KEEP_CRITICAL | 57 | 0.6 | 57 / 0 / 0 |
| `playwright-report/` | REGENERABLE_CANDIDATE | 1 | 0.5 | 0 / 0 / 1 |
| `.playwright-cli/` | UNKNOWN_HOLD | 50 | 0.5 | 38 / 0 / 12 |
| `schemas/` | KEEP_CRITICAL | 100 | 0.4 | 100 / 0 / 0 |
| `providers/` | KEEP_CRITICAL | 55 | 0.3 | 55 / 0 / 0 |
| `pipeline/` | KEEP_CRITICAL | 13 | 0.2 | 13 / 0 / 0 |
| `core/` | KEEP_CRITICAL | 17 | 0.1 | 17 / 0 / 0 |
| `.agents/` | KEEP_CRITICAL | 11 | 0.1 | 11 / 0 / 0 |
| `golden/` | KEEP_TEST | 4 | 0.1 | 4 / 0 / 0 |
| `docs/` | KEEP_EVIDENCE | 3 | 0.1 | 3 / 0 / 0 |
| `qa/` | KEEP_TEST | 8 | 0.0 | 8 / 0 / 0 |
| `mcp/` | KEEP_CRITICAL | 13 | 0.0 | 13 / 0 / 0 |
| `context/` | KEEP_CRITICAL | 2 | 0.0 | 2 / 0 / 0 |
| `platforms/` | KEEP_CRITICAL | 7 | 0.0 | 7 / 0 / 0 |
| `brand/` | KEEP_CRITICAL | 3 | 0.0 | 3 / 0 / 0 |
| `policy/` | KEEP_CRITICAL | 5 | 0.0 | 5 / 0 / 0 |
| `assets/` | KEEP_CRITICAL | 2 | 0.0 | 2 / 0 / 0 |

Root-level files (13): `.env`, `.env.example`, `.gitignore`, `.zcodeignore`, `AGENTS.md`, `opencode.json`, `package-lock.json`, `package.json`, `PILOT_INPUT.yaml`, `playwright.config.js`, `skills-lock.json`, `start-flow.ps1`, `UNFOLDIQ_REPOSITORY_AUDIT_TREE_SAFE_CLEANUP_PROMPT.md`

## B. Depth 2-3 (folders ≥ 0.5 MB or with UNTRACKED content)

| Path | Class | Files | MB | T / U / I |
|---|---|---:|---:|---|
| `.claude/worktrees/` | UNKNOWN_HOLD | 2,028 | 1151.7 | 0 / 0 / 2,028 |
| `.opencode/node_modules/` | KEEP_CRITICAL | 3,667 | 52.5 | 0 / 0 / 3,667 |
| `.opencode/ponytail/` | UNKNOWN_HOLD | 195 | 2.9 | 0 / 0 / 195 |
| `.opencode/ponytail/.git/` | UNKNOWN_HOLD | 29 | 1.2 | 0 / 0 / 29 |
| `.opencode/ponytail/assets/` | UNKNOWN_HOLD | 14 | 1.1 | 0 / 0 / 14 |
| `flow-companion/extension/` | KEEP_CRITICAL | 68 | 1.1 | 35 / 0 / 33 |
| `out/final/` | KEEP_APPROVED | 14 | 56.8 | 0 / 0 / 14 |
| `out/final/pilot-sky-blue/` | KEEP_APPROVED | 12 | 6.3 | 0 / 0 / 12 |
| `out/final/postv1-flow-live-validation/` | KEEP_APPROVED | 1 | 2.0 | 0 / 0 / 1 |
| `out/incremental-5b/` | REGENERABLE_CANDIDATE | 28 | 305.4 | 0 / 0 / 28 |
| `out/incremental-5b/cache/` | REGENERABLE_CANDIDATE | 12 | 32.5 | 0 / 0 / 12 |
| `out/incremental-5c/` | REGENERABLE_CANDIDATE | 13 | 177.8 | 0 / 0 / 13 |
| `out/longform-5c/` | REGENERABLE_CANDIDATE | 2 | 466.6 | 0 / 0 / 2 |
| `out/pilot-sky-blue-canonical/` | KEEP_APPROVED | 9 | 36.2 | 0 / 0 / 9 |
| `projects/phase1g12-case-a/` | KEEP_EVIDENCE | 125 | 6.9 | 125 / 0 / 0 |
| `projects/phase1g12-case-a/downloads/` | KEEP_EVIDENCE | 8 | 2.6 | 8 / 0 / 0 |
| `projects/phase1g12-case-a/qa/` | KEEP_EVIDENCE | 47 | 1.9 | 47 / 0 / 0 |
| `projects/phase1g12-case-a/render/` | KEEP_EVIDENCE | 11 | 2.0 | 11 / 0 / 0 |
| `projects/phase1hyg-validation/` | KEEP_EVIDENCE | 9 | 32.5 | 9 / 0 / 0 |
| `projects/phase1hyg-validation/inventory/` | KEEP_EVIDENCE | 3 | 32.4 | 3 / 0 / 0 |
| `projects/phase2-1-validation/` | KEEP_EVIDENCE | 40 | 16.8 | 40 / 0 / 0 |
| `projects/phase2-1-validation/assets/` | KEEP_EVIDENCE | 14 | 16.7 | 14 / 0 / 0 |
| `projects/pilot-sky-blue/` | KEEP_TEST | 165 | 23.2 | 165 / 0 / 0 |
| `projects/pilot-sky-blue-canonical/` | KEEP_APPROVED | 136 | 105.0 | 106 / 30 / 0 |
| `projects/pilot-sky-blue-canonical/assets/` | KEEP_APPROVED | 37 | 18.7 | 37 / 0 / 0 |
| `projects/pilot-sky-blue-canonical/render/` | KEEP_APPROVED | 40 | 86.0 | 10 / 30 / 0 |
| `projects/pilot-sky-blue/assets/` | KEEP_TEST | 28 | 9.1 | 28 / 0 / 0 |
| `projects/pilot-sky-blue/render/` | KEEP_TEST | 82 | 13.9 | 82 / 0 / 0 |
| `projects/postv1-flow-live-validation/` | KEEP_EVIDENCE | 11 | 3.5 | 11 / 0 / 0 |
| `projects/postv1-flow-live-validation/_incoming/` | KEEP_EVIDENCE | 1 | 1.5 | 1 / 0 / 0 |
| `projects/postv1-flow-live-validation/assets/` | KEEP_EVIDENCE | 5 | 2.0 | 5 / 0 / 0 |
| `projects/validation/` | KEEP_EVIDENCE | 107 | 33.1 | 107 / 0 / 0 |
| `projects/validation/post-1h-physical-migration/` | KEEP_EVIDENCE | 19 | 32.5 | 19 / 0 / 0 |
| `remotion/.agents/` | KEEP_CRITICAL | 275 | 2.2 | 275 / 0 / 0 |
| `remotion/.agents/skills/` | KEEP_CRITICAL | 275 | 2.2 | 275 / 0 / 0 |
| `remotion/.render-binaries/` | KEEP_CRITICAL | 22 | 220.1 | 0 / 0 / 22 |
| `remotion/node_modules/` | KEEP_CRITICAL | 14,719 | 970.8 | 0 / 0 / 14,719 |
| `remotion/public/` | KEEP_TEST | 60 | 43.8 | 11 / 49 / 0 |
| `remotion/public/postv1-validation/` | KEEP_TEST | 2 | 1.7 | 2 / 0 / 0 |
| `remotion/public/unfoldiq/` | KEEP_TEST | 58 | 42.1 | 9 / 49 / 0 |
| `Report/archive/` | KEEP_EVIDENCE | 37 | 0.5 | 37 / 0 / 0 |
| `Report/evidence/` | KEEP_EVIDENCE | 204 | 28.9 | 196 / 8 / 0 |
| `Report/evidence/phase-6a/` | KEEP_EVIDENCE | 65 | 25.3 | 57 / 8 / 0 |
| `Report/evidence/post-v1f-real-execution/` | KEEP_EVIDENCE | 62 | 2.7 | 62 / 0 / 0 |
| `Report/phases/` | KEEP_EVIDENCE | 40 | 0.8 | 40 / 0 / 0 |
| `Report/phases/phase-1g/` | KEEP_EVIDENCE | 19 | 0.5 | 19 / 0 / 0 |
| `research/.venv/` | REGENERABLE_CANDIDATE | 22,046 | 1358.3 | 0 / 0 / 22,046 |
| `research/.venv-deep/` | REGENERABLE_CANDIDATE | 37,576 | 780.6 | 0 / 0 / 37,576 |

## Legend

KEEP_CRITICAL, KEEP_APPROVED, KEEP_TEST, KEEP_EVIDENCE, REGENERABLE_CANDIDATE, ARCHIVE_CANDIDATE, DUPLICATE_CANDIDATE, UNREFERENCED_UNVERIFIED, SENSITIVE_OR_SESSION, UNKNOWN_HOLD per the audit prompt §4. Labels are rule-based (see `REPO_FULL_INVENTORY.csv`) and substantiated in `REPO_DEPENDENCY_USAGE.md`.

Empty on-disk folders (not in git): `projects/active`, `projects/archive`, `projects/demos`, `out/debug`, `out/preview`, `out/temp`, `out/test`, `.playwright`.

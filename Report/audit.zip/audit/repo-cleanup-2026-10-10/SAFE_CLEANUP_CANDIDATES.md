# SAFE_CLEANUP_CANDIDATES

AUDIT_ONLY. **Nothing here has been executed.** Order: LOWEST_RISK → HIGHEST_RISK. Decision vocabulary: `SAFE_TO_PROPOSE | REVIEW_REQUIRED | KEEP | UNKNOWN_HOLD` (no AUTO_DELETE). Sizes are measured logical bytes from the scan; "verified reclaim" = 0 until a regeneration is actually executed and compared, "estimate" = measured size of the path. Nothing is compressed in these figures.

Owner approval format wanted: exact IDs, e.g. `APPROVE C02, C03, C06`. Not a blanket "clean all".

## Decision table

| Decision | Candidate IDs | Files | MB (measured) | Risk |
|---|---|---:|---:|---|
| MAY_DELETE_AFTER_APPROVAL | C01–C05 (C06 = KEEP) | 19 | 10.8 | very low |
| MAY_DELETE_AFTER_APPROVAL (re-render cost) | C07, C08 | 41 | 483.2 | low–medium |
| ARCHIVE_AFTER_APPROVAL | C09, C10 | 4 | ~466.6 + 64.4 | medium |
| UNKNOWN / HOLD | C11–C15 | 2,090 | 1,151.7 worktree + 25.3 review media (+ 66.9 attempts flagged KEEP) | high |
| KEEP (explicit) | K01–K10 | rest | ~5.2 GiB | — |

Potential reclaimable (estimate, MEDIUM confidence): **≈ 0.49 GB** for C01–C05 + C07 + C08, **≈ 0.96 GB** if C09 (long-form renders, Phase 7-sensitive) is also removed/archived off-disk. Verified reclaimable: **0 B** (no regeneration executed in audit). Not counted: venvs (LOW), node_modules (needed), worktree (UNKNOWN_HOLD, ≈1.13 GB potential after C11 steps).

---

## Candidates

Common fields for every row: *Owner approval needed = YES*. *Rollback* = restore from the pre-delete manifest/archive described in `CLEANUP_ROLLBACK_AND_TEST_PLAN.md` §2. Git status IGNORED unless stated; deleting ignored files is invisible to git, so rollback relies on archive/regen only.

### C01 — `playwright-report/` — REVIEW_DELETE — SAFE_TO_PROPOSE
- dir, IGNORED, 1 file, 0.5 MB (`index.html`).
- Role: stale default Playwright HTML report. `playwright.config.js` now sends the HTML reporter to `Report/evidence/playwright/html` and artifacts to `Report/evidence/playwright/artifacts`.
- Readers: none found in code/tests (`rg playwright-report` hits only `lib/workspace/index.js`, `scripts/cli/hygiene-classify.js` as a lifecycle name, and the POST-1H inventory).
- Phase 6B/7: none; Phase 7 E2E writes to the configured Report path.
- Regeneration: `npm run test:e2e` (NOT executed). Confidence MEDIUM–HIGH. Risk: loses one old report. Reclaim est. 0.5 MB.

### C02 — `remotion/out/` (still.png, video.mp4) — REVIEW_DELETE — SAFE_TO_PROPOSE
- dir, IGNORED, 2 files, 0.11 MB. Ad-hoc Remotion output; not named in any registry or test (searched folder name only; a render-time consumer by relative path was not exhaustively excluded → MEDIUM).

### C03 — `research/__pycache__/` — REVIEW_DELETE — SAFE_TO_PROPOSE
- dir, IGNORED, 1 file, 0.04 MB. Python bytecode, regenerated on next import. HIGH.

### C04 — `out/kokoro-test.wav` — REVIEW_DELETE — SAFE_TO_PROPOSE
- file, IGNORED, 168,044 B, 2026-10-06. **0 references** in repo, Report, docs, projects. Scratch TTS probe. MEDIUM (zero refs ≠ proof, but there is no consumer name and it is a loose file under `out/` root).

### C05 — `remotion/public/unfoldiq/pilot-sky-blue/{1e32ff63,888c103e,9eb151c7,ae235976,c5d25dcc,d583c136}/` — REVIEW_DELETE — REVIEW_REQUIRED
- 6 dirs, UNTRACKED, 14 files total (incl. in C05), ≈ 10.0 MB. Render staging copies for the *demo* project `pilot-sky-blue`.
- Evidence: SHA-256 confirms S01–S06 videos in these dirs are byte-identical to `remotion/public/unfoldiq/pilot-sky-blue-canonical/<same hash>/` (e.g. `1e32ff63/S01.mp4`, `888c103e/S06.mp4`, `c5d25dcc/S03.mp4`). Tracked sibling dirs for the same project (e.g. `24aff353`, `2f265d52`, `80138344`) remain.
- Risk: the demo project's re-render could need its staging (staging is re-created by the render pipeline — **not tested**). Phase 6B/7: demo project is a regression fixture (7 test files) but tests stage at run-time per `render-fixture-lifecycle.js` contract. Confidence MEDIUM.
- Do **not** touch `pilot-sky-blue-canonical/` staging (see K02).

### C06 — empty folders `out/debug, out/preview, out/temp, out/test, projects/active, projects/archive, projects/demos, .playwright` — INDEX_ONLY / KEEP
- Empty on disk, 0 B. Named in POST-1H migration maps; removing gains nothing. **Recommend KEEP** (listed so the owner can see they were examined). `.playwright` is name-protected (session) even though empty.

### C07 — `out/incremental-5c/` — REVIEW_DELETE — REVIEW_REQUIRED
- dir, IGNORED, 13 files, 177.8 MB (+ 5 base/cand chunk pairs with identical content: `base-chunk-0-900.mp4` == `cand-chunk-0-900.mp4` etc., DUP groups in CSV).
- Writer/reader: `tests/incremental/test-pilot-reuse-5c.js` (OUT5C), "probe-verified" resume artefacts. Distilled results are in `Report/phases/phase-5/…` and `Report/evidence/perf-5b`.
- Phase 6B: none known. Phase 7: may want a long-form incremental baseline — rebuild cost = re-render. Regeneration: run that test file via the project runner (NOT executed). Confidence MEDIUM. Risk: next full regression takes longer; no data loss because outputs are deterministic renders (determinism not proven).

### C08 — `out/incremental-5b/` — REVIEW_DELETE — REVIEW_REQUIRED
- dir, IGNORED, 28 files, 305.4 MB, incl. `cache/CAS/` (32.5 MB, content-addressed duplicates of chunk files, e.g. CAS `3915dcc4…` == `chunk-v1-0-900.mp4`).
- Writer/reader: `tests/incremental/test-pilot-repair-a.js`, `-repair-b.js`, `test-pilot-reuse-5c.js` (all use `out/incremental-5b`). **Delete C07 and C08 together or not at all** (reuse-5c reads 5b).
- Worktree note: the claude worktree has 6 CAS files that do **not** exist here (C11), so these two trees are not byte-identical backups of each other.
- Confidence MEDIUM.

### C09 — `out/longform-5c/` — REVIEW_ARCHIVE — REVIEW_REQUIRED
- dir, IGNORED, 2 files, 466.6 MB (`longform-10min.mp4` 168.0 MB, `longform-20min.mp4` 298.7 MB) — the two largest files in the repo.
- Writer: `tests/perf/test-longform-5c.js` (resumable per duration). Evidence cited by 14 Report files + MARKET_GAP_REGISTRY.
- **Phase 7 needs long-form E2E evidence** → these are the only local long-form renders. Recommend ARCHIVE (external drive + sha256) or KEEP until the Phase 7 plan says whether it re-renders. DELETE only if the owner accepts a 10/20-minute re-render. Confidence MEDIUM.

### C10 — tracked 32 MB inventories — REVIEW_ARCHIVE — UNKNOWN_HOLD-leaning
- `projects/phase1hyg-validation/inventory/repo-inventory.json` (32.2 MB) and `projects/validation/post-1h-physical-migration/rollback/repo-inventory.before.json` (32.1 MB). TRACKED. Both are POST-1H hygiene/rollback evidence for a registry project (`phase1hyg-validation` ACTIVE, `post-1h-physical-migration` ACTIVE).
- `lib/workspace/index.js` and `scripts/cli/repo-inventory.js` reference the file names; whether they *read* them was not proven. Removing tracked files = tracked change + registry/artifact hash impact. Confidence LOW → **cannot be a DELETE**; at most archive-with-pointer after owner OK. Working-tree saving 64.4 MB.

### C11 — `.claude/worktrees/unfoldiq-phase-6a-closure-de7296/` — UNKNOWN_HOLD
- Git worktree (branch `claude/unfoldiq-phase-6a-closure-de7296`), 2,028 files, 1,151.7 MB, of which 1,037.7 MB is its own `out/`.
- Facts: branch has **0 commits not in `main`** (11 behind) → merged. `git status` shows 2 modified tracked files, **EOL-only** (`git diff --ignore-cr-at-eol` empty).
- But: path+size comparison against `main` shows **12 files in the worktree's `out/` missing from main** and 2 that differ — `out/creative-repair-6a/{source-v1.mp4 (8.0 MB), repaired-v2.mp4 (7.6 MB), 4 frame jpgs}`, 6 `incremental-5b/cache/CAS/*` (incl. a 30.8 MB chunk). ≈ 16 MB unique. `creative-repair-6a` is cited by `PHASE_6A_CREATIVE_RETENTION_FOUNDATION_REPORT.md`, `tests/fixtures/creative-project-fixture.js` and `Report/evidence/phase-6a/phase-6a-creative-repair-execution.json`.
- Proposal (needs owner OK): (1) copy the unique `out/creative-repair-6a/` files into main `out/` or an archive with sha256, (2) then `git worktree remove` (non-force) after resolving the EOL-only diff. Potential gain ≈ 1.13 GB. Not a delete until step 1 is verified.

### C12 — `Report/evidence/phase-6a/canonical-pilot/*.{mp3,mp4}` (8 files) — UNKNOWN_HOLD
- UNTRACKED, 25.3 MB: `narration-en-kokoro-speed-1.{1,2,3}.mp3`, `narration-vi-review{,-x1.5}.mp3`, `preview-en-x1.{2,3,5}.mp4`. 0 references for 7 of them, 1 for `narration-vi-review.mp3`.
- Owner review inputs for narration speed decision (Phase 6A closure). Not safe to infer disposable. Option: owner confirms → archive; or `git add` as evidence.

### C13 — `projects/pilot-sky-blue-canonical/render/attempts/attempt-001…005/` — KEEP (flagged)
- UNTRACKED, 29 files, ≈ 66.9 MB (outputs 17.2, 15.0, 14.7, 15.1 MB + logs). attempt-006 (approved) is tracked.
- Cited by `PHASE_6A_CANONICAL_PILOT_REPORT.md` as lineage. **Not a cleanup candidate**; risk flag: they exist only on this disk. Recommend owner decide to track or back up.

### C14 — `.playwright-cli/` — UNKNOWN_HOLD
- 50 files, 0.5 MB: 38 TRACKED (despite the `.playwright-cli/` ignore rule) + 12 ignored. Console logs and page snapshots (`.yml`) from 2026-10-01/03 sessions; snapshots can contain page content. Not read. Tiny gain → leave.

### C15 — `.opencode/ponytail` — UNKNOWN_HOLD
- Tracked as gitlink (mode 160000, commit e3ba2aa) **without** `.gitmodules`; `git submodule status` errors. `opencode.json` loads a plugin from this path. Report as a repo-hygiene defect, no action in cleanup.

---

## Explicit KEEP list (not candidates)

| ID | Path | Why |
|---|---|---|
| K01 | `out/pilot-sky-blue-canonical/` (final.mp4, final.prev.mp4, json) | sha256 `7954a86a…` == owner-approval == attempt-006. `final.prev.mp4` is a confirmed duplicate (18.1 MB) but `tests/pipeline/test-finalize-output.js` asserts it exists after re-finalize; leave. |
| K02 | `projects/pilot-sky-blue-canonical/` + `remotion/public/unfoldiq/pilot-sky-blue-canonical/` | approved canonical + its staging manifest |
| K03 | `out/final/pilot-sky-blue/` | pinned DURABLE in artifact-registry (`final.mp4` 3f684657…) ; `final.prev.mp4` duplicate also kept |
| K04 | `out/final/pilot-4b.mp4` (48.5 MB) | written + hash-read by `tests/render/test-pilot-4b.js`; cited by Phase 4B/5B/6A reports |
| K05 | `out/final/postv1-flow-live-validation/` | artifact-registry RETENTION_MANAGED |
| K06 | `tests/`, `golden/`, `qa/`, `projects/pilot-sky-blue/`, validation projects | regression + golden; see matrix |
| K07 | `.env`, `Report/hardening/storage-state-experiment.json`, `.playwright/` | SENSITIVE_OR_SESSION, contents not read |
| K08 | `remotion/.render-binaries/` (220 MB) | SAC workaround; reinstall needs manual SAC toggle |
| K09 | `node_modules/` ×3 (2.0 GB) | active dev; `npm ci` possible but not during a cycle; remotion tree needed for render |
| K10 | `research/.venv`, `research/.venv-deep` (2.1 GB) | reinstall via `scripts/maintenance/setup-*.js` untested → LOW, no delete proposal |

## Questions for owner (approve by ID)

1. C01–C04: OK to delete after manifest? (11 MB, trivial)
2. C07+C08: accept re-render cost for 5B/5C incremental tests in exchange for 483 MB?
3. C09: Phase 7 plan — will it reuse 10/20-min renders (keep/archive) or re-render (delete)?
4. C11: should unique worktree files be saved first, then the worktree removed?
5. C12/C13: track in git, archive, or leave?

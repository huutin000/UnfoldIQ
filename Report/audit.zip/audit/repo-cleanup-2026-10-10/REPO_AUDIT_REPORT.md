# REPO_AUDIT_REPORT — UNFOLDIQ repository inventory, logical tree & safe-cleanup audit

Date 2026-10-10 · Mode AUDIT_ONLY · HEAD `1096429` (main) · Windows 11 · `EXTERNAL_PAID_COST_VND = 0`

```text
REPO_AUDIT = COMPLETE   (with documented limits in §5)
DESTRUCTIVE_ACTIONS = 0
PHYSICAL_MOVES = 0
SOURCE_CHANGES = 0
TRACKED_CHANGES = 0     (git diff + git diff --cached empty; only new untracked: Report/audit/)
PROTECTED_ARTIFACTS = VERIFIED   (canonical final sha256 7954a86a… matches approval, final-artifact, attempt-006)
REFERENCE_GRAPH = PARTIAL        (static + registry + test-path edges verified; dynamic render staging & external CI not executed/found)
PHASE_6B_7_RETENTION = READY
POTENTIAL_RECLAIMABLE_BYTES = measured candidate sizes ≈ 0.49 GB (C01–C05,C07,C08) / ≈ 0.96 GB with C09; VERIFIED reclaim = 0 (nothing regenerated)
RECOMMENDED_DEFAULT = NO_PHYSICAL_MOVE
OWNER_APPROVAL_REQUIRED = YES
```

## 1. Metrics (measured)

| | Files | Logical size |
|---|---:|---:|
| Total on disk | 84,830 | 6.87 GiB (7,373,613,214 B) |
| TRACKED | 2,079 | 173.4 MB (2.5 %) |
| UNTRACKED (non-ignored) | 88 | 132.0 MB |
| IGNORED | 82,663 | 6.57 GiB (95.7 %) |

Where the bytes are: `research/.venv*` 2.14 GB · `remotion/node_modules`+`.render-binaries` 1.19 GB · `.claude/worktrees` 1.15 GB · `out/` 1.04 GB · root `node_modules` 1.01 GB · `projects/` 221 MB · `.git` 132 MB. Source/tests/docs (core, lib, tests, scripts…) < 10 MB combined. Symlinks/junctions/submodules(mapped): 0 / 0 / 0. Allocated (cluster) size not measured.

Preflight: 2 worktrees (main + `.claude/worktrees/unfoldiq-phase-6a-closure-de7296`); initial `git status` = 88 untracked, 0 modified; ignored top-level groups summarised without listing secret contents.

## 2. Key findings

1. **Disk is ~96 % ignored/regenerable-ish; source layout is not the problem.** A physical restructure would give no measurable benefit and breaks hash-locked paths → `NO_PHYSICAL_MOVE`.
2. **Canonical pilot is intact** but partly **only on this disk**: attempts 001–005 (66.9 MB) and 8 Phase 6A review media files (25.3 MB) are untracked; staging `remotion/public/unfoldiq/pilot-sky-blue-canonical/` (49 untracked files) likewise. Protect + consider tracking/backup.
3. **The biggest "cleanup" targets are test output caches in `out/`** (longform-5c 467 MB, incremental-5b 305 MB, incremental-5c 178 MB), written by named tests. Deleting is functionally safe-looking but regeneration was not run; longform renders are Phase 7-sensitive.
4. **The 1.15 GB claude worktree is NOT safely removable yet**: merged (0 ahead, 11 behind) and EOL-only diff, but its ignored `out/` contains ≈ 16 MB not present in main, including `creative-repair-6a/*` cited by Phase 6A evidence.
5. Confirmed duplicates (SHA-256): 65 groups / 144 MB redundant; most are intentional (approved finals + `.prev`, tracked vs staged copies, 3 identical `phase1g12-case-a` attempts). Only the untracked `pilot-sky-blue/<hash>` staging twins (10 MB) were proposed.
6. `__5b_pilot__`/`__5c_long__` fixtures don't exist on disk (self-cleaning lifecycle) — nothing to remove.
7. Hygiene defects (no action taken): `.opencode/ponytail` gitlink with no `.gitmodules`; 38 `.playwright-cli/` files tracked despite ignore rule; `Report/INDEX.md` header stale; `out/pilot-sky-blue-canonical/final.mp4` and `out/final/pilot-4b.mp4` absent from `artifact-registry.json`; two tracked 32 MB inventory JSONs.

## 3. Decision table

| Decision | IDs | Files | MB | Risk |
|---|---|---:|---:|---|
| KEEP | K01–K10 + all source/tests/golden/Report/projects | ~83.9k | ~5,300 (incl. node_modules, venvs, worktree excluded) | – |
| MAY_DELETE_AFTER_APPROVAL | C01–C05, C07, C08 | 60 | 493.8 | very low → low/medium (re-render cost) |
| ARCHIVE_AFTER_APPROVAL | C09 (+ C10 low) | 4 | 466.6 (+64.4) | medium |
| UNKNOWN_HOLD | C11 worktree, C12 review media, C14, C15 | ~2,100 | ~1,178 | high |
| KEEP (flagged) | C13 canonical attempts 001–005 | 29 | 66.9 | – |

Full per-candidate fields (path, bytes, readers, regen command, risk, rollback, approval) are in `SAFE_CLEANUP_CANDIDATES.md`.

## 4. Deliverables (this folder)

`REPO_TREE_OVERVIEW.md` · `REPO_FULL_INVENTORY.csv` (2,464 rows: every file outside bulk folders + one summary row per bulk dir; no secrets read) · `REPO_DISK_USAGE_TOP.md` · `REPO_DEPENDENCY_USAGE.md` · `PROJECT_FIXTURE_RETENTION_MATRIX.md` · `LOGICAL_DIRECTORY_MAP.md` · `SAFE_CLEANUP_CANDIDATES.md` · `CLEANUP_ROLLBACK_AND_TEST_PLAN.md` · this report.
Location: `Report/audit/repo-cleanup-2026-10-10/` (AGENTS.md: reports live under `Report/`). The folder is untracked; commit only if you ask.

## 5. Unsupported assumptions / limits / blockers

- Inventory classification is **rule-based by path** (rules visible in the generator's logic and notes column); only the items discussed in §2/the candidates were individually inspected.
- Regeneration of any `out/` cache, staging dir or venv was **not executed**; "regenerable" is by reading writers, not by proof. No full regression, no paid API, no Playwright run.
- Not verified: canonical Roadmap V6.2 (outside repo), Phase 6B task text, external Flow profile/bridge token/auth-state, GitHub CI, Markdown relative-link integrity, allocated disk size, existence of every path named in AGENTS.md routes.
- Duplicate hashing covered files ≥ 64 KiB outside bulk folders only; the worktree comparison used path + size (not hash).
- `.env`, `Report/hardening/storage-state-experiment.json`, `.playwright*` were never opened.
- Blockers to deletion: C09 depends on the Phase 7 plan; C11 on saving unique files; C10 on proof of non-use.

## 6. Questions for the owner (approve by exact ID)

1. Approve C01–C05? (≈ 11 MB, trivial.)
2. Accept re-render time for 5B/5C incremental tests to free C07+C08 (483 MB)?
3. Phase 7: reuse or re-render the 10/20-min long-form videos (C09)? Archive off-disk?
4. Save unique worktree files, then remove the worktree (C11, ≈ 1.13 GB)?
5. Track in git or back up: canonical attempts 001–005 and Phase 6A review media (C12/C13)?
6. Allow a follow-up task for the hygiene defects in §2.7 (docs/registry only)?

**Stopped here. No cleanup will be performed until you approve exact candidate IDs.**

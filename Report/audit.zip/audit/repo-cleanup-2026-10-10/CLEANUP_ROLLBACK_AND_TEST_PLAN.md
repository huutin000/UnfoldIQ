# CLEANUP_ROLLBACK_AND_TEST_PLAN

PLAN ONLY. Nothing here is executed until the owner approves exact candidate IDs from `SAFE_CLEANUP_CANDIDATES.md` in a separate execution task.

## 0. Prohibited (restated)
`git clean -fdx`, wide `git checkout -- <dir>`, `git reset --hard`, unscoped `rm -rf`/`rmdir`/`del`, unreviewed move/rename, touching `.env`, auth/session folders, approved outputs. Preview with scoped `git clean -n -d -X -- <path>` only. `git worktree remove` without `--force` only.

## 1. Pre-flight (once)
1. `git status --porcelain=v1 -uall` must equal the audit snapshot + `Report/audit/…` (stop on any new untracked/sensitive file).
2. Re-verify protected hashes: `sha256sum out/pilot-sky-blue-canonical/final.mp4 projects/pilot-sky-blue-canonical/render/attempts/attempt-006/output.mp4` = `7954a86a793ccbe5e153be30875b832ef813f3e23021e0f571a9da5e823dfcdf`; `out/final/pilot-sky-blue/final.mp4` = `3f684657a9ed…`.
3. Back up the **untracked-only** protected set to a location outside the repo with a sha256 manifest: canonical attempts 001–005 (66.9 MB), `Report/evidence/phase-6a/canonical-pilot/*.{mp3,mp4}` (25.3 MB), `remotion/public/unfoldiq/pilot-sky-blue-canonical/` (untracked part). (They have no git copy.)
4. Create a branch only if tracked files will change (C10 only).

## 2. Per-group procedure, rollback and checks

Rollback principle: ignored/untracked files are invisible to git, so rollback = (a) archive restore or (b) regeneration. Both must be prepared **before** deletion. For each group write `before-manifest.csv` (path, bytes, sha256) into `Report/audit/…/execution/`.

| Group | Steps | Rollback | Post-check (targeted only) |
|---|---|---|---|
| G1 C01–C04 (11 MB scratch) | write manifest → delete exact listed paths | `playwright-report`: `npm run test:e2e`; `remotion/out`: re-render; `__pycache__`: auto; `kokoro-test.wav`: copy from the zip taken in step 1 (168 KB) | `npm run check:repo-structure` |
| G2 C05 (10 MB staging dupes) | confirm each file's sha256 equals its `pilot-sky-blue-canonical/<hash>/` twin → delete 6 dirs | re-stage via renderer **or** restore from zip | `npm run test:render` (domain) after exporting nothing else; `npx remotion compositions` |
| G3 C07+C08 (483 MB) | move-free: first copy `chunks-v1.json`, `input-v*.json`, `ctx-a.json` (tiny control files) to evidence; delete both trees together | re-run `node scripts/run-tests.js incremental` (regenerates; time cost high, **untested**) or restore archive | `node scripts/run-tests.js incremental` run once to prove regeneration, record time + pass/fail |
| G4 C09 (467 MB) — only after Phase 7 decision | `robocopy`/copy to external drive + sha256 manifest, verify, then delete | copy back | `node tests/perf/test-longform-5c.js` only if owner wants regeneration proof (long) |
| G5 C11 worktree | (1) copy `out/creative-repair-6a/*` and 6 missing CAS files from the worktree into main `out/` (or archive) and verify sha256; (2) resolve EOL-only diff; (3) `git worktree remove <path>` (no `--force`); (4) optional `git branch -d claude/unfoldiq-phase-6a-closure-de7296` (merged) | `git worktree add` from the branch + restore archive | `git worktree list`, `git status` |
| G6 C10 tracked inventories | **needs branch + proof that `lib/workspace` and `scripts/cli/repo-inventory.js` do not read them** | `git revert` / `git checkout <sha> -- <file>` (scoped to these 2 files) | `npm run check:workspace`, `npm run check:repo-structure`, `node scripts/run-tests.js workspace storage` |

Never in this plan: C12/C13 deletion, venvs, node_modules, `.render-binaries`, `.playwright*`, `.env`.

## 3. Test strategy
- Disposable outputs only (G1–G4): targeted smoke above; **no** 195-suite run.
- Anything touching tracked source/config/registry (G6, or C10/Report index edits): targeted domain tests, `check:repo-structure`, `check:workspace`, then **one** full `npm test` at the final stabilised snapshot if impact justifies.
- Browser-impacting? None of these touch UI/extension/DOM → Playwright E2E not required; confirm with owner if C14 (`.playwright-cli` tracked files) is ever approved.
- Record exact commands, before/after bytes (`REPO_DISK_USAGE_TOP.md` method), and results in the execution report. Claim reclaimed bytes only from post-delete scan.

## 4. Stop conditions
New untracked/sensitive file; unknown link target; a hash mismatch; unexpected test failure; a candidate path found referenced by code not seen in the audit; owner-approved list contains a protected path.

## 5. Approval template
```
APPROVE: C01, C02, C03, C04, C05, C07, C08
HOLD:    C09, C10, C11, C12, C13, C14, C15
```

# PROJECT_FIXTURE_RETENTION_MATRIX

Source: `projects/registry.json` (21 entries), `projects/artifact-registry.json`, `rg` reference counts (lib+scripts+pipeline+mcp+flow-companion+core+providers / tests / golden+docs+qa / Report), per-folder byte scan. Classification labels per audit prompt §5B. **No project is proposed for deletion.**

## Per-project

| Project ID | Path | Registry | Class | Files / MB | Git | Refs (code/tests/gold-docs/Report) | Phase 6B | Phase 7 | Future | Regenerable (verified)? | Decision |
|---|---|---|---|---:|---|---|---|---|---|---|---|
| pilot-sky-blue-canonical | `projects/pilot-sky-blue-canonical` | DEMO/ACTIVE | **APPROVED_CANONICAL** | 136 / 105.0 | 106 T + 30 U | 0/0/0/9 | style/rubric baseline, Originality input | continuity/QA reference | lineage | **No** (owner-approved, hash-locked) | **PIN / KEEP** |
| pilot-sky-blue | `projects/pilot-sky-blue` | DEMO/ACTIVE | GOLDEN_PROJECT / AUTOMATED_TEST_FIXTURE | 165 / 23.2 | T | 4/7/2/28 | golden regression | regression | regression | No | KEEP |
| phase1g12-case-a | `projects/phase1g12-case-a` | ACTIVE (manifest) | ACTIVE_REAL_PROJECT / test fixture | 125 / 6.9 | T | 7/5/2/9 | consumed by tests | – | regression | No | KEEP |
| phase2-1-validation | same | VALIDATION/ACTIVE (manifest) | AUTOMATED_TEST_FIXTURE | 40 / 16.8 | T | 6/5/2/5 | voice-bible tests | – | regression | No | KEEP |
| phase223-narration-pronunciation | same | VALIDATION/ACTIVE | AUTOMATED_TEST_FIXTURE | 13 / 0.07 | T | 1/5/2/5 | yes | – | regression | No | KEEP |
| phase1hyg-validation | same | VALIDATION/ACTIVE | HISTORICAL_EXPERIMENT (hygiene evidence) | 9 / 32.5 | T | 2/1/0/3 | – | – | rollback evidence | No | KEEP (C10 archive question) |
| post-1h-physical-migration | `projects/validation/…` | VALIDATION/ACTIVE | HISTORICAL_EXPERIMENT (rollback) | 19 / 32.5 | T | 1/0/0/2 | – | – | rollback | No | KEEP (C10) |
| postv1-flow-live-validation | same | DEBUG/FROZEN | HISTORICAL_EXPERIMENT | 11 / 3.5 | T | 0/0/0/5 | – | – | artifact-registry final (RETENTION_MANAGED) | No | KEEP |
| postv1b-flow-companion-live | same | DEBUG/FROZEN | HISTORICAL_EXPERIMENT | 14 / 0.05 | T | 4/3/0/17 | – | Flow regression | – | No | KEEP |
| channel-mascot | same | DEMO/ACTIVE | DEMO_SHOWCASE | 26 / 0.03 | T | 1/1/0/6 | – | – | – | – | KEEP |
| phase1h1…h67-validation (5) | `projects/validation/phase-1h/*` | VALIDATION/FROZEN | AUTOMATED_TEST_FIXTURE | 53 / 0.32 total | T | 0/1–3/0/6–7 each | referenced by tests | – | regression | No | KEEP |
| phase1g12-hardening | `projects/validation/phase-1g/…` | VALIDATION/FROZEN | HISTORICAL_EXPERIMENT | 35 / 0.28 | T | 0/0/0/4 | – | – | – | No | KEEP (tiny) |
| HARDENING_1G12 | `projects/HARDENING_1G12` | VALIDATION/FROZEN | HISTORICAL_EXPERIMENT | 6 / 0.01 | T | 0/1/0/6 | – | – | – | No | KEEP |
| DBG_1G12, DBG_H4, E2E_bench_panel, live-1g1-http308 | `projects/debug/*` | DEBUG/FROZEN | HISTORICAL_EXPERIMENT (registry: REGENERABLE/ARCHIVED) | 18 / 0.04 total | T | 0/0/0/1–3 | – | – | – | not proven | UNKNOWN_HOLD→KEEP (nothing to gain) |
| `__5b_pilot__`, `__5c_long__`, `__5c_conc__` | (do not exist on disk) | never registered | AUTOMATED_TEST_FIXTURE (self-cleaning) | 0 | – | tests: 5 files | created+removed per run | created+removed | – | **Yes, by design** | nothing to do |
| projects/active, archive, demos | empty dirs | – | UNKNOWN | 0 | not in git | – | – | – | – | – | KEEP (zero bytes) |

Unique test contracts are all single-instance, so no demo/fixture project is a safe dedupe target. Largest project cost is the approved canonical (105 MB: 86 MB `render/` incl. 6 attempts).

## Phase retention matrix

| Resource | Phase 6B | Phase 7 | Future / release | Regeneration verified? | Decision |
|---|---|---|---|---|---|
| `tests/` (213 files, 2.4 MB, auto-discovered) | dependency-based | E2E regression | regression | n/a | KEEP |
| `golden/` (4 json) + `tests/golden/` | Originality / creative fixtures | Golden Gate | regression | not assumed | KEEP |
| `qa/` (8) | QA contract | QA gate | regression | – | KEEP |
| Approved pilot (`projects/pilot-sky-blue-canonical`, `out/pilot-sky-blue-canonical`, staging) | style/rubric baseline | continuity/QA reference | lineage | **No** | **PIN** |
| canonical attempts 001–005 (untracked, 66.9 MB) | – | – | lineage cited by Phase 6A report | No | KEEP; back up/track (owner) |
| `projects/pilot-sky-blue` + `out/final/pilot-sky-blue` | golden regression | regression | regression | No (pinned in registry) | KEEP |
| `out/final/pilot-4b.mp4` | hash-read by test | – | Phase 4B/5B cited | test re-writes it | KEEP |
| `out/incremental-5b`, `-5c` (483 MB) | none known | incremental/resume baseline maybe | – | **not executed** | REVIEW_DELETE (C07/C08) |
| `out/longform-5c` (467 MB) | none | **long-form E2E evidence (Phase 7)** | – | not executed | REVIEW_ARCHIVE (C09) |
| `Report/evidence/**` (28.9 MB) | gate evidence | gate evidence | audit | n/a | KEEP |
| `Report/evidence/phase-6a/canonical-pilot` untracked media (25.3 MB) | owner review inputs | – | – | No | UNKNOWN_HOLD |
| claude worktree `out/creative-repair-6a` | Phase 6A creative-repair evidence | – | – | No (not in main) | UNKNOWN_HOLD (C11) |
| `research/.venv*` | research deep provider | maybe | – | untested | KEEP |
| `remotion/.render-binaries` | render | render | render | needs manual SAC toggle | KEEP |

# LOGICAL_DIRECTORY_MAP

**Navigation only. No path is moved, renamed, linked or junctioned.** Every entry is a relative link to an existing path. Recommended default: `NO_PHYSICAL_MOVE`.

Why no move: tests are auto-discovered by directory (`scripts/run-tests.js`), `projects/registry.json` and `artifact-registry.json` store physical paths and hashes, owner-approval/final-artifact JSON hard-code `out/…` and `render/attempts/…`, and Report files cite these paths. `git mv` would not update any of that.

```text
UNFOLDIQ — LOGICAL NAVIGATION (not actual directory moves)
├── ENGINE/        [KEEP_CRITICAL]
│   ├── core/ (17 files)  lib/ (212)  pipeline/ (13)  schemas/ (100)  policy/ (5)
│   └── scripts/ → cli/ (31) · diagnostics/ (15) · checks/ (4) · maintenance/ (6)
├── INTEGRATION/   [KEEP_CRITICAL]
│   └── providers/ (55)  platforms/ (7)  flow-companion/ (86; extension/.output ignored)  mcp/ (13)
├── CREATIVE/
│   ├── research/ (4 tracked; .venv* 2.1 GB ignored)  context/ (2)  assets/ (2)  brand/ (3)
│   └── remotion/ → src/ (20) · public/ (staging, mixed T/U) · .agents/ (275 vendored skill files) · .render-binaries/ (ignored)
├── QUALITY/       [KEEP_TEST]
│   └── tests/ (213 — auto-discovered)  golden/ (4)  qa/ (8)  playwright.config.js
├── WORKSPACES/    [REVIEW_BY_PROJECT — see PROJECT_FIXTURE_RETENTION_MATRIX.md]
│   └── projects/ → pilot-sky-blue-canonical ⭐ approved · pilot-sky-blue (golden) · phase*-validation · validation/ · debug/ · channel-mascot
├── GOVERNANCE/    [KEEP_EVIDENCE]
│   └── AGENTS.md  docs/ (roadmap, MARKET_GAP_REGISTRY)  Report/ (phases, evidence, fixes, archive, hardening, current)  skills-lock.json
├── RUNTIME/       [IGNORED / MIXED — never blind-clean]
│   └── out/ (final = approved · longform/incremental = regenerable)  node_modules/ ×3  playwright-report/  .playwright-cli/
├── TOOLING/
│   └── .agents/  .claude/ (skills; worktrees = UNKNOWN_HOLD)  .opencode/  opencode.json  start-flow.ps1  package.json
└── SENSITIVE/     [do not open]
    └── .env  .playwright/  Report/hardening/storage-state-experiment.json  (+ external Flow profile / bridge token)
```

## Link index (existing paths)

| Domain | Entry points |
|---|---|
| Start here | [AGENTS.md](../../../AGENTS.md) · [core/WORKFLOW.md](../../../core/WORKFLOW.md) · [Report/INDEX.md](../../INDEX.md) (stale header, see below) |
| Engine | [core/](../../../core) · [lib/](../../../lib) · [pipeline/](../../../pipeline) · [schemas/](../../../schemas) · [policy/](../../../policy) |
| Integration | [providers/INDEX.md](../../../providers/INDEX.md) · [platforms/INDEX.md](../../../platforms/INDEX.md) · [flow-companion/](../../../flow-companion) · [mcp/](../../../mcp) |
| Creative | [research/](../../../research) · [context/ROUTES.yaml](../../../context/ROUTES.yaml) · [remotion/src/](../../../remotion/src) |
| Quality | [tests/](../../../tests) · [golden/](../../../golden) · [qa/](../../../qa) |
| Workspaces | [projects/registry.json](../../../projects/registry.json) · [projects/artifact-registry.json](../../../projects/artifact-registry.json) · [pilot-sky-blue-canonical](../../../projects/pilot-sky-blue-canonical) |
| Governance | [docs/roadmap/MARKET_GAP_REGISTRY.md](../../../docs/roadmap/MARKET_GAP_REGISTRY.md) · [Phase 6A reports](../../phases/phase-6) |
| Audit | this folder |

(`context/ROUTES.yaml`, `providers/INDEX.md`, `platforms/INDEX.md`, `core/WORKFLOW.md` are named by AGENTS.md; existence was not separately re-checked in this audit.)

## Zero-move improvements (proposals, not executed)

1. Refresh the header of `Report/INDEX.md` (currently says FIX_PRE_2_4; baseline is Phase 6A COMPLETE) and add a "Phase 6" section pointing to `Report/phases/phase-6/*` and `Report/audit/…`.
2. Add one `README.md`-style index per heavy generated area **inside** its existing folder (e.g. `out/README.md` listing what is APPROVED vs REGENERABLE) — documentation only; do not rely on it from code.
3. Extend the existing `artifact-registry.json` (already has `retentionClass` + `pinned`) with entries for `out/pilot-sky-blue-canonical/final.mp4` and `out/final/pilot-4b.mp4` (currently absent) — a registry data change that needs its own approval.
4. Fix `.opencode/ponytail` gitlink/.gitmodules mismatch and the 38 tracked `.playwright-cli/` files (hygiene defects, separate task).
5. Retention policy for `out/`: failures-only / keep-last-N for test output caches.

## Optional future physical tree — NOT PROPOSED FOR EXECUTION

A physical regroup (`engine/`, `integration/`, …) would touch: every `require("../../lib/…")` relative path (count not measured), `package.json` scripts, `scripts/run-tests.js` discovery, `playwright.config.js`, registry/artifact-registry physical paths + tree hashes, owner-approval and final-artifact JSON (hash-locked), Report citations, AGENTS.md rules and `check:repo-structure`. Measured benefit: none (size/clutter is in ignored folders, not in source layout). Verdict: **do not do it**.
